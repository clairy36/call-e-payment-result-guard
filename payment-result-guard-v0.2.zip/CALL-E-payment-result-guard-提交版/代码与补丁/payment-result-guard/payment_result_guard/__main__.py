"""Bounded stdin/stdout protocol. No network, credentials or financial actions."""
import json
import sys
from .core import evaluate, decision


def main():
    if sys.argv[1:] == ['--demo']:
        # Explicit synthetic evidence, separate from extracted fields.
        e = {'schema_version':'0.1','scenario':'payment_recovery',
             'context':{'object_id':'demo','currency':'USD','amount_minor':10000,'locale':'en-US'},
             'source':{'call_id':'demo','binding':'matched','scope':'single_attempt','data_origin':'synthetic'},
             'claims':{'decision':'retry_now','evidence':'Please retry my payment now.'},
             'turns':[{'id':'r0:a0:t0','speaker':'user','text':'Please retry my payment now.'}]}
        print(json.dumps({'input':e,'decision':evaluate(e)}, indent=2))
        return 0
    try:
        raw = sys.stdin.buffer.read(262145)
        if len(raw) > 262144:
            raise ValueError('input limit')
        e = json.loads(raw)
        out = evaluate(e)
        print(json.dumps(out, allow_nan=False))
        return 2 if out['reason_codes'] == ['INVALID_INPUT'] else 0
    except (ValueError, UnicodeError):
        print(json.dumps(decision()))
        return 2
    except Exception:
        print(json.dumps(decision(reason='VALIDATOR_UNAVAILABLE')))
        return 1

if __name__ == '__main__':
    sys.exit(main())
