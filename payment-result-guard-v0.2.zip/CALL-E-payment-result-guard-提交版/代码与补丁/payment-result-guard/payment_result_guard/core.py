"""Pure checks over an explicitly bounded conversation, not factual verification."""
from __future__ import annotations
import re
from .scenarios import classify


def decision(status='needs_review', effect='review_required', reason='INVALID_INPUT', *, kind='unknown', refs=(), origin='synthetic', **values):
    return {'schema_version': '0.1', 'claim_status': status,
            'business_effect_status': effect, 'normalized_claim': {'kind': kind, **values},
            'reason_codes': [reason] if reason else [], 'evidence_refs': list(refs),
            'next_step': 'record_claim' if effect == 'recordable' else 'operator_review',
            'execution_authorized': False, 'data_origin': origin}


def _valid(e):
    if not isinstance(e, dict) or e.get('schema_version') != '0.1':
        return False
    if e.get('scenario') not in ('payment_promise', 'payment_recovery'):
        return False
    if any(not isinstance(e.get(k), dict) for k in ('source', 'claims', 'context')):
        return False
    c, s = e['context'], e['source']
    if any(not isinstance(c.get(k), str) or not c[k] for k in ('object_id', 'currency', 'locale')):
        return False
    if type(c.get('amount_minor')) is not int or c['amount_minor'] <= 0:
        return False
    if any(not isinstance(s.get(k), str) for k in ('call_id', 'scope', 'binding', 'data_origin')) or not s['call_id']:
        return False
    ts = e.get('turns')
    if not isinstance(ts, list) or len(ts) > 1000:
        return False
    if any(not isinstance(t, dict) or any(not isinstance(t.get(k), str) for k in ('id','speaker','text')) for t in ts):
        return False
    if any(not t['id'] or len(t['text']) > 10000 for t in ts) or len({t['id'] for t in ts}) != len(ts):
        return False
    claim = e['claims']
    key = 'evidence_quote' if e['scenario'] == 'payment_promise' else 'evidence'
    if key in claim and not isinstance(claim[key], str):
        return False
    return True


def normalize(text):
    return re.sub(r'\s+', ' ', text.strip()).casefold()


def evaluate(envelope):
    if not _valid(envelope):
        return decision()
    e = envelope
    origin = e['source']['data_origin']
    def stop(code, status='needs_review'):
        return decision(status, reason=code, origin=origin)
    if e['source']['binding'] != 'matched':
        return stop('OBJECT_MISMATCH')
    if e['source']['scope'] != 'single_attempt':
        return stop('AMBIGUOUS_SOURCE')
    if e['context']['locale'] != 'en-US' or e['context']['currency'] != 'USD':
        return stop('UNSUPPORTED_EXPRESSION', 'unsupported')
    claims = e['claims']
    if e['scenario'] == 'payment_recovery' and claims.get('decision') not in ('retry_now','update_card','pause_subscription','no_answer','unknown'):
        return stop('INVALID_INPUT')
    if e['scenario'] == 'payment_promise' and claims.get('outcome') not in ('promise_to_pay','already_paid'):
        return stop('UNSUPPORTED_EXPRESSION', 'unsupported')
    quote = claims.get('evidence_quote' if e['scenario'] == 'payment_promise' else 'evidence', '')
    turns = e['turns']
    if not turns or not quote.strip():
        return stop('MISSING_EVIDENCE')
    candidates = [i for i,t in enumerate(turns) if normalize(quote) in normalize(t['text'])]
    if not candidates:
        return stop('QUOTE_NOT_FOUND')
    customer = [i for i in candidates if turns[i]['speaker'] == 'user']
    if not customer:
        return stop('WRONG_SPEAKER')
    if len(customer) != 1:
        return stop('AMBIGUOUS_SOURCE')
    i = customer[0]
    # Examine the entire cited turn and later customer turns, not the selected substring alone.
    relevant = ' '.join(t['text'] for t in turns[i:] if t['speaker'] == 'user')
    if re.search(r"\b(?:cannot|can't|won't|will not|do not|don't|never|no|not)\b", relevant, re.I):
        return decision('contradicted', reason='CONTRADICTORY_EVIDENCE', refs=[turns[i]['id']], origin=origin)
    if re.search(r'\b(?:if|unless|provided|subject to|pending|only after)\b', relevant, re.I):
        return decision('conditional', reason='CONDITIONAL_STATEMENT', kind='conditional_plan', refs=[turns[i]['id']], origin=origin)
    if re.search(r'\b(?:actually|instead|correction|wait|rather)\b', relevant, re.I):
        return stop('CONTRADICTORY_EVIDENCE')
    later = [t for t in turns[i+1:] if t['speaker'] != 'bot' and normalize(t['text']).rstrip('.!') not in ('thanks','thank you','goodbye')]
    if later:
        return stop('UNSUPPORTED_EXPRESSION', 'unsupported')
    result = classify(e, i)
    return decision(**result, refs=[turns[i]['id']], origin=origin)
