"""Experimental payment-call evidence checks; never execution authorization."""
from .core import evaluate

__all__ = ["evaluate"]
