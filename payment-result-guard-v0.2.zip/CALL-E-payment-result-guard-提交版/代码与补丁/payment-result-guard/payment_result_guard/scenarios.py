"""Small, explicit English grammars. Unrecognized text is never auto-accepted."""
import re
from datetime import date, datetime
from decimal import Decimal, InvalidOperation

AMOUNT = r'(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{1,2})?'
DATE = r'(?:\d{4}-\d{2}-\d{2}|[A-Za-z]+ \d{1,2},? \d{4})'
PROMISE = re.compile(rf"(?:I will|I'll|We will|We'll|I promise to|We promise to) (?:pay|send) (?:USD\s*|\$)?(?P<amount>{AMOUNT})(?: dollars| USD)? (?:on|by) (?P<date>{DATE})[.!]?", re.I)
RETRY = re.compile(r"(?:Yes[, ]+)?(?:please )?retry (?:my|the|this) (?:payment|charge|card)(?: (?:right )?now)?[.!]?", re.I)
PAID = re.compile(r'I (?:already paid|have paid) (?:this|the) (?:invoice|bill|payment)[.!]?', re.I)


def amount_minor(value):
    if not isinstance(value, str) or not re.fullmatch(AMOUNT, value):
        return None
    try:
        number = Decimal(value.replace(',', ''))
        return int(number * 100) if 0 < number <= Decimal('1000000000') else None
    except (InvalidOperation, ValueError):
        return None


def absolute_date(value):
    if not isinstance(value, str):
        return None
    for fmt in ('%Y-%m-%d', '%B %d, %Y', '%B %d %Y'):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            pass
    return None


def classify(e, index):
    text = e['turns'][index]['text'].strip()
    claims = e['claims']
    def reject(reason='UNSUPPORTED_EXPRESSION', status='unsupported'):
        return {'status':status, 'effect':'review_required', 'reason':reason}
    if re.match(r'(?:the )?customer\b', text, re.I):
        return reject(status='needs_review')
    if PAID.fullmatch(text):
        if e['scenario'] == 'payment_promise' and claims['outcome'] != 'already_paid':
            return reject('CONTRADICTORY_EVIDENCE', 'contradicted')
        if e['scenario'] == 'payment_recovery' and claims['decision'] != 'unknown':
            return reject('CONTRADICTORY_EVIDENCE', 'contradicted')
        return {'status':'supported','effect':'pending_external_verification','reason':'PAYMENT_SUCCESS_NOT_VERIFIED','kind':'reported_paid'}
    if e['scenario'] == 'payment_promise':
        minor = amount_minor(claims.get('promised_amount'))
        if minor is None:
            return reject('AMBIGUOUS_AMOUNT')
        target_date = absolute_date(claims.get('promised_date'))
        if target_date is None:
            return reject()
        match = PROMISE.fullmatch(text)
        if not match:
            return reject()
        if claims['outcome'] != 'promise_to_pay' or amount_minor(match['amount']) != minor or absolute_date(match['date']) != target_date:
            return reject('CONTRADICTORY_EVIDENCE', 'contradicted')
        return {'status':'supported','effect':'recordable','reason':None,'kind':'payment_promise','amount_minor':minor,'date':target_date}
    if claims['decision'] == 'retry_now':
        direct = RETRY.fullmatch(text)
        # A short yes is only usable against a single, explicit retry question.
        short = re.fullmatch(r'yes(?:,? please)?[.!]?', text, re.I)
        previous = e['turns'][index-1] if index else None
        question = previous and previous['speaker'] == 'bot' and re.fullmatch(r'(?:May|Can|Should) (?:I|we) retry (?:your|the) (?:payment|charge|card)(?: (?:right )?now)?\?', previous['text'].strip(), re.I)
        if direct or (short and question):
            return {'status':'supported','effect':'advisory_only','reason':'PAYMENT_SUCCESS_NOT_VERIFIED','kind':'retry_requested'}
    return reject()
