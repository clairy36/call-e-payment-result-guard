# Payment result guard

An experimental offline result-consumption example for CALL-E payment workflows.
It checks two separate questions: does the supplied customer speech support the
extracted claim, and which intermediate business state can that claim support?
It is not an identity check, payment verifier, execution permission or general NLP model.

## Setup

From the community repository root, using Python 3.11+ and Node 22:

```bash
python3.11 -m venv ../.venv
source ../.venv/bin/activate
python -m pip install -e apps/python/payment-result-guard
python -m pip install -e 'apps/python/kept[dev]'
npm --prefix apps/typescript/recover ci
```

Dependency installation may use the network. Tests and the default demo need no
API keys and make no real calls or payments. No package is published to PyPI.
The sibling package is installed explicitly, not fetched as a private dependency.

## Run

```bash
python -m payment_result_guard --demo
python apps/python/payment-result-guard/scripts/verify.py --output ../guard-report
```

The first command demonstrates a synthetic retry request that stays advisory.
The second runs the core, kept and Recover suites, and writes logs and a JSON
report with per-scenario denominators, false accepts/rejects, and separate handling
counts. Install dependencies first; the harness never installs or deploys anything.
`fixtures/cases.json` contains explicit synthetic claims, turns and expected results.
The harness is source-tree tooling; fixtures are not a production SDK dataset.

For individual inputs, pipe JSON to `python -m payment_result_guard`. Stdout contains
one decision. Exit 0 means a decision was produced (including refusal), 2 means bad
input, and 1 means an internal error. Input is limited to 256 KiB. Do not interpret
exit 0, `supported`, or `recordable` as permission to execute a financial action.

## What is supported

- `payment_promise`: a single English customer statement with an explicit numeric
  USD amount and ISO date or full English month/day/year, e.g.
  `I will pay USD 100.00 on 2026-10-10.`
- `payment_recovery`: an explicit retry request, or a short yes immediately after
  one unambiguous retry question. Intent remains advisory.
- A limited `I already paid this invoice.` statement is recorded as reported paid;
  independent payment verification remains missing.
- One bound recipient and one completed attempt, speaker `user`. Unknown speakers,
  missing transcripts, paraphrases, ambiguous scopes and unsupported expressions
  do not auto-pass. Relative dates, spoken number words, other languages/currencies,
  approximate amounts and ranges are outside automatic acceptance.

The grammars are intentionally narrow. Quote existence is checked separately from
meaning. Conditional, negative and correction cues are inspected in the full cited
turn and subsequent customer turns; unusual phrasing can still be misunderstood.
These are synthetic regression results, not natural-language accuracy or measured
collections impact. See [validation and boundaries](../../../docs/payment-result-guard/validation.md).

## Integration and trust boundary

`evaluate(envelope)` is pure and returns a claim status, business status, reason
codes and source references. It always returns `execution_authorized: false`.
`source.binding` describes a host check; a CLI caller can forge this label, so the
CLI never authenticates a call. Arbitrary `external_facts` never produce settled or
recovered states. Context must come from the host's own business records.

kept calls the same module after its existing binding and policy gates and before
constructing a Promise. Recover calls it after authenticated authoritative lookup
and before persisting an advisory. Its Node-only bridge uses a fixed module name,
stdin JSON, no shell, a five-second timeout and a 256 KiB output bound. Set
`PAYMENT_GUARD_PYTHON` to the installed environment's absolute Python path when
starting Recover. Missing/broken interpreters yield review, not silent acceptance.
This adds a local Python dependency; it is not an Edge/serverless deployment recipe.

No scheduler, payment executor or cancellation service is created. Existing host
controls remain in charge. Disabling/removing the check requires an explicit code
change; an unavailable check must not fall back to the previous acceptance path.
No raw credentials or phone numbers are required in guard outputs. Host masking
and retention policies still apply to the original result.


## Scripted-call replay supplement

Run `python scripts/replay.py` from this app after installing the package. This
makes zero calls and replays three sanitized fictional AI-to-AI dialogue samples.
`--require-targets` exits 1 because P01 and P02 lack an exact target line; the
ordinary mode exits 0 when existing observed results remain reproducible.
A passing regression must not be presented as complete scenario coverage.

The replay reports provider completion, exact recipient target matching, extracted
amount consistency, observed condition text, and core decisions separately. Exact
matching is a fixture acquisition check, not a general semantic classifier. It
never changes source amounts or authorizes business writes. Full transcription
and extraction are not re-executed. See the [iteration record](../../../docs/payment-result-guard/iterations.md).
