import copy
import json
from pathlib import Path
import subprocess
import sys
import pytest
from payment_result_guard.core import evaluate

CASES = json.loads((Path(__file__).parents[1] / 'fixtures/cases.json').read_text())

@pytest.mark.parametrize('case', CASES.values(), ids=CASES.keys())
def test_contract(case):
    before = copy.deepcopy(case['input'])
    out = evaluate(case['input'])
    assert out['claim_status'] == case['expected']['claim_status']
    assert out['business_effect_status'] == case['expected']['business_effect_status']
    if case['expected']['reason']:
        assert case['expected']['reason'] in out['reason_codes']
    assert out['execution_authorized'] is False
    assert case['input'] == before

@pytest.mark.parametrize('bad', [None, [], {}, {'schema_version':'0.1'}, {'schema_version':False}])
def test_malformed_is_closed(bad):
    assert evaluate(bad)['reason_codes'] == ['INVALID_INPUT']

def test_cli_bad_json_does_not_echo_private_input():
    p = subprocess.run([sys.executable, '-m', 'payment_result_guard'], input='private-secret{', text=True, capture_output=True)
    assert p.returncode == 2
    assert 'private-secret' not in p.stdout + p.stderr
    assert json.loads(p.stdout)['reason_codes'] == ['INVALID_INPUT']

def test_cli_decision_exit_zero():
    p = subprocess.run([sys.executable, '-m', 'payment_result_guard'], input=json.dumps(CASES['kept_negative']['input']), text=True, capture_output=True)
    assert p.returncode == 0
    assert json.loads(p.stdout)['claim_status'] == 'contradicted'

@pytest.mark.parametrize('question, expected', [
    ('May I retry your payment now?', 'supported'),
    ('Would you like to retry or update your card?', 'unsupported'),
])
def test_short_yes_must_answer_one_specific_question(question, expected):
    e = copy.deepcopy(CASES['recover_ok']['input'])
    e['claims']['evidence'] = 'Yes, please.'
    e['turns'] = [{'id':'q','speaker':'bot','text':question},{'id':'a','speaker':'user','text':'Yes, please.'}]
    assert evaluate(e)['claim_status'] == expected

@pytest.mark.parametrize('text', [
    'I will pay USD 200.00 on 2026-10-10.',
    'I will pay USD 100.00 on 2026-10-11.',
    'I will pay USD 100.00 on 2026-10-10. Perhaps.',
    'She said I will pay USD 100.00 on 2026-10-10.',
])
def test_unseen_variants_never_silently_change_terms(text):
    e = copy.deepcopy(CASES['kept_ok']['input'])
    e['claims']['evidence_quote'] = text
    e['turns'][0]['text'] = text
    assert evaluate(e)['business_effect_status'] != 'recordable'

@pytest.mark.parametrize('field,value', [('promised_amount', True),('promised_date',None)])
def test_bad_typed_terms(field, value):
    e = copy.deepcopy(CASES['kept_ok']['input']); e['claims'][field] = value
    assert evaluate(e)['claim_status'] != 'supported'

def test_duplicate_turn_ids_invalid():
    e = copy.deepcopy(CASES['kept_ok']['input']); e['turns'].append(e['turns'][0].copy())
    assert evaluate(e)['reason_codes'] == ['INVALID_INPUT']
