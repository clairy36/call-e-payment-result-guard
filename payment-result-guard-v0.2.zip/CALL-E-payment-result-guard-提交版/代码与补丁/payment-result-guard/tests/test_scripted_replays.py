import copy
import json
from pathlib import Path
import subprocess
import sys
import pytest
from scripts.replay import assess

APP = Path(__file__).resolve().parents[1]
CASES = json.loads((APP / 'fixtures/scripted-replays.json').read_text())

@pytest.mark.parametrize('case', CASES, ids=lambda c: c['id'])
def test_observed_replay(case):
    before = copy.deepcopy(case)
    result = assess(case)
    assert all(result[k] == v for k, v in case['expected'].items())
    assert result['execution_authorized'] is False
    assert case == before

def test_caller_prompt_and_provider_completion_do_not_prove_target():
    case = copy.deepcopy(CASES[2])
    for turn in case['input']['turns']:
        if turn['speaker'] == 'user':
            turn['speaker'] = 'bot'
    assert assess(case)['target_line_present'] is False

def test_regression_success_does_not_claim_complete_coverage():
    script = str(APP / 'scripts/replay.py')
    ordinary = subprocess.run([sys.executable, script], capture_output=True, text=True)
    strict = subprocess.run([sys.executable, script, '--require-targets'], capture_output=True, text=True)
    assert ordinary.returncode == 0
    assert strict.returncode == 1
    assert json.loads(ordinary.stdout)['targets_complete'] is False
