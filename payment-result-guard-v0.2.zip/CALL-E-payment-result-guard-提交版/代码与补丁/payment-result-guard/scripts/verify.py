#!/usr/bin/env python3
"""Reproducible local harness: core, two adapters, two host paths, no live services.
Run with the Python environment containing kept, payment-result-guard and pytest.
Install Recover dev dependencies beforehand. Does not install anything or deploy.
"""
import argparse
from collections import Counter
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from payment_result_guard import evaluate

APP = Path(__file__).resolve().parents[1]
ROOT = APP.parents[2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    report = {'data_origin':'synthetic', 'real_integration':False, 'components':{}, 'scenarios':{}}
    env = dict(os.environ, CALLE_API_KEY='mock', PAYMENT_GUARD_PYTHON=sys.executable,
               NEXT_TELEMETRY_DISABLED='1', STRIPE_SECRET_KEY='', CALLE_WEBHOOK_SECRET='fixture-only')
    commands = {
        'core': ([sys.executable,'-m','pytest','tests','-o','addopts=','-q'], APP),
        'scripted_replay': ([sys.executable, 'scripts/replay.py'], APP),
        'kept': ([sys.executable,'-m','pytest','tests','-o','addopts=','-q'], ROOT/'apps/python/kept'),
        'recover': (['npm','test'], ROOT/'apps/typescript/recover'),
    }
    ok = True
    for name,(command,cwd) in commands.items():
        start = time.monotonic()
        try:
            result = subprocess.run(command,cwd=cwd,env=env,capture_output=True,text=True,timeout=180)
            log = result.stdout + result.stderr
            passed = result.returncode == 0
        except (OSError,subprocess.TimeoutExpired) as exc:
            log = type(exc).__name__
            passed = False
        (args.output/f'{name}.log').write_text(log)
        report['components'][name] = {'passed':passed,'seconds':round(time.monotonic()-start,2),'command':command,
          'evidence_level':('simulation' if name == 'core' else 'sanitized_scripted_call_replay' if name == 'scripted_replay' else 'local_runtime_integration')}
        print(f'{name}: {"PASS" if passed else "FAIL"}')
        ok &= passed
    cases = json.loads((APP/'fixtures/cases.json').read_text())
    for scenario in ('payment_promise','payment_recovery'):
        rows=[]
        for name,c in cases.items():
            if c['input']['scenario'] != scenario: continue
            actual=evaluate(c['input']); expected=c['expected']
            matched = all(actual[k] == expected[k] for k in ('claim_status','business_effect_status')) and (not expected['reason'] or expected['reason'] in actual['reason_codes'])
            rows.append({'id':name,'expected':expected,'actual':actual,'matched':matched})
        states=Counter(r['actual']['claim_status'] for r in rows)
        false_accept=sum(r['actual']['claim_status']=='supported' and r['expected']['claim_status']!='supported' for r in rows)
        false_reject=sum(r['actual']['claim_status']!='supported' and r['expected']['claim_status']=='supported' for r in rows)
        report['scenarios'][scenario]={'denominator':len(rows),'false_accept':false_accept,'false_reject':false_reject,'handling_counts':dict(states),'rows':rows}
        ok &= all(r['matched'] for r in rows)
    report['passed']=bool(ok)
    (args.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(f'Report: {args.output / "report.json"}')
    return 0 if ok else 1

if __name__ == '__main__':
    sys.exit(main())
