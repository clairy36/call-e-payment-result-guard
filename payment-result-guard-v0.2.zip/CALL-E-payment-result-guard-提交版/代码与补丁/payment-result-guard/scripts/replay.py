#!/usr/bin/env python3
"""Offline replay of sanitized scripted calls; no credentials or network needed.

Exact target matching is deliberately strict: this checks fixture acquisition,
not general speech semantics. Provider completion never implies target coverage.
"""
import argparse
from decimal import Decimal, InvalidOperation
import json
from pathlib import Path
from payment_result_guard import evaluate

APP = Path(__file__).resolve().parents[1]


def assess(case):
    envelope = case['input']
    answers = [t['text'].strip() for t in envelope['turns'] if t['speaker'] == 'user']
    raw_amount = envelope['claims'].get('promised_amount', 'unknown')
    try:
        amount_matches = Decimal(raw_amount) * 100 == envelope['context']['amount_minor']
    except (InvalidOperation, ValueError, TypeError):
        amount_matches = None
    decision = evaluate(envelope)
    return {
        'id': case['id'],
        'provider_task_completed': case['provider_task_completed'],
        'target_line_present': case['target_line'] in answers,
        'amount_matches': amount_matches,
        'condition_present': any('if approved' in text.casefold() for text in answers),
        'claim_status': decision['claim_status'],
        'business_effect_status': decision['business_effect_status'],
        'reason_codes': decision['reason_codes'],
        'execution_authorized': decision['execution_authorized'],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--require-targets', action='store_true',
                        help='Exit 1 when any scripted target is absent, even if regression matches.')
    args = parser.parse_args()
    cases = json.loads((APP / 'fixtures/scripted-replays.json').read_text())
    rows = [assess(case) for case in cases]
    regression = all(all(row[k] == v for k, v in case['expected'].items())
                     and row['execution_authorized'] is False
                     for case, row in zip(cases, rows))
    targets = all(row['target_line_present'] for row in rows)
    print(json.dumps({'evidence_level': 'sanitized_scripted_call_replay',
                      'live_calls_this_run': 0, 'host_integration_verified': False,
                      'regression_passed': regression, 'targets_complete': targets,
                      'rows': rows}, indent=2))
    return 0 if regression and (targets or not args.require_targets) else 1


if __name__ == '__main__':
    raise SystemExit(main())
