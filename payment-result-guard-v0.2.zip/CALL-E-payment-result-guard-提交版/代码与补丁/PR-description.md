# feat(payment-result-guard): check payment-call evidence before workflow records

kept could record a payment promise from a conditional amount or contradictory
quote. Recover already keeps financial effects advisory, but its retry advice
used an extracted decision without checking that customer speech supports it.

This focused experimental contribution adds one bounded offline Python checker,
a kept adapter before Promise construction, and a Recover Node adapter before
advice persistence. It preserves existing host controls and reports evidence
failures for review. Recover's zero-recovery boundary is existing behavior, not
new functionality. No SDK, payment service, scheduler or production platform is
introduced.

## Why this opportunity

CALL-E provides phone execution and structured results; community apps consume
those results inside business workflows. Developers need traceable evidence and
explicit state prerequisites. Payment follow-up supplies two related cases for
reusing that boundary without equating a spoken intent with a completed payment.

Existing Verity, Rebuttal, Kol and Trunkline implementations informed the design;
their appointment/dispute/claim engines are not imported as generic validators.
kept's real SDK simulator and ledger path, and Recover's authoritative lookup and
advisory persistence, are reused directly.

## Validation

See the included verification harness and docs/payment-result-guard/validation.md.
The harness runs core regression, two adapter replays, kept's SDK-to-ledger path,
and Recover's actual POST plus shared Python process. The original core and host-path suites use synthetic speech;
Recover's provider and DB boundaries are mocked. Those suites make no live call or payment.
Final exact counts and command outputs accompany the local validation report.
Repository validation and changed-file lint are checked separately. Recover's
pre-existing page lint error remains explicitly reported.

## Tradeoffs and responsibility

Only bounded en-US numeric USD and absolute-date expressions auto-pass. Unsupported
phrasing is reviewed; updated positive fixtures do not claim better general NLP
accuracy. Python subprocess integration is local Node-only and adds an interpreter
dependency. Timeout/malformed output must not fall back to unguarded acceptance.

No actual financial execution, recovered-state verification, remote deployment,
new UI or webhook outbox is included. Original webhook re-fetch recovery limitations
remain. A subsequent iteration would expand representative transcripts and operator
feedback, then separately verify real host integrations with explicit authorization.

AI assisted research, implementation, regression tests and documentation; the user
selected scope, two-case validation and business boundaries. Synthetic pass rates
are not claimed as business conversion or recovery improvements.


## Scripted replay supplement

Three sanitized fictional AI-to-AI call samples now replay offline. Provider task
completion, target-line acquisition, amount consistency, and guard decisions are
reported separately. Five additional tests bring current local validation to
307 tests (63 core, 195 kept, 49 Recover). `--require-targets` intentionally exits
1: only P03 has the exact target line; P01 is incomplete and P02 has an amount
mismatch. This adds validation artifacts, not new financial safeguards. The core
and adapters are unchanged. No live call occurs in this replay harness. Prior
live calls are author-observed scripted tests, not production host integration.
See docs/payment-result-guard/iterations.md for chronology and remaining gaps.
